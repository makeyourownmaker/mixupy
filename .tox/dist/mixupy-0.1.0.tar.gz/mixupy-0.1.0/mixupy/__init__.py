"""Data augmentation with the mixup method"""
from mixupy.mixup import mixup  # noqa


__version__ = "0.1.0"
